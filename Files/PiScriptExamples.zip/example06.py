from piscript.PiModule import *
from math import *
import Vector as V

init("example06", 460, 460)


# Radius of circle
r = 4


def f(t):
	return ([r*math.cos(t),r*math.sin(t)])

def df(t):
	u=[r*math.sin(t),-r*math.cos(t)]
	return (u)

beginpage()
center()
scale(72/2.54)

# Circle
gsave()
newpath()
setlinewidth(0.1)
circle([0,0],r)
fill(0.3,0.2,0.7)
stroke()
grestore()

#Draw Tangents

nTangents = 6

for i in range(0,nTangents):
	gsave()
	a = (2*math.pi*i)/float(nTangents)
	translate(f(a))
	setarrowdims(0.1,0.3)
	newpath()
	arrow(df(a)[0],df(a)[1])
	fill(0.7,0,0.4)
	newpath()
	arrow(-df(a)[1],df(a)[0])
	fill(0.2,0.6,0.4)
	grestore()


endpage()
flush()
