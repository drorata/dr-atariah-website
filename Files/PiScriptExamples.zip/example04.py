from piscript.PiModule import *
from math import *

init("example04", 330, 280)

beginpage()
center()
scale(4*72/2.54)
translate(-0.2,0)

#Radius of the vertices
vRadius = 0.03

#Number of branches
n = 13.0
#
c = 2.0/n

newpath()
moveto(-1,-1)
lineto(-1,1)
lineto(1,1)
for i in range(1,n):
	if i%2 == 0:
		lineto(0,1-i*c)
		lineto(1,1-i*c)
	else:
		lineto(1,1-i*c)
		lineto(0,1-i*c)
lineto(1,1-n*c)
closepath()
fill(0.45)
stroke()

for i in range(0,n-n/2+1):
	newpath()
	circle([1,1-c/2 - 2*i*c],vRadius)
	fill()

gsave()
translate(1+0.1,1-c/2-0.1)
scale(0.02)	
place(texinsert("$l_1$"))
grestore()	

gsave()
translate(1+0.1,1-c/2-2*c-0.1)
scale(0.02)	
place(texinsert("$l_2$"))
grestore()

gsave()
translate(1+0.1,1-c/2-10*c-0.1)
scale(0.02)	
place(texinsert("$l_{k-1}$"))
grestore()


gsave()
translate(1+0.1,1-c/2-12*c-0.1)
scale(0.02)	
place(texinsert("$l_k$"))
grestore()

newpath()
circle(0,0,vRadius)
fill()
gsave()
translate(-0.2,0)
scale(0.02)	
place(texinsert("$p$"))
grestore()

newpath()
moveto(1+0.03,1-6*c)
setdeg()
arc(1+0.03,1-5*c-c/2,c/2,270,90)
stroke()

gsave()
translate(1+0.25,1-5*c-c/2)
scale(0.007*2)
settexenv("latex")
t = texinsert("$\\frac{2}{2k-1}$")
place(t)
grestore()

newpath()
moveto(1+0.03,1-9*c)
setdeg()
arc(1+0.03,1-8*c-c/2,c/2,270,90)
stroke()

gsave()
translate(1+0.25,1-8*c-c/2)
scale(0.007*2)
settexenv("latex")
t = texinsert("$\\frac{2}{2k-1}$")
place(t)
grestore()

endpage()
flush()
