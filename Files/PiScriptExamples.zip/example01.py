from piscript.PiModule import *

init("example01", 58, 58)

beginpage()
center()
scale(72/2.54)
newpath()
moveto(-1, -1)
lineto(1, -1)
lineto(1, 1)
lineto(-1, 1)
closepath()
fill(0, 1, 0)
stroke()
# Square is 2x2 cm and it fits into a ~58x58 ADP square
endpage()


finish()

