from piscrip.PiModule import *
from math import *

init("example08", 400, 400)

def divCircle(x,y,r):
	if r<0.9:
		return()
	else:
		newpath()
		moveto(x+r,y)
		circle([x+r/2.0,y],r/2.0)
		stroke(1-r/(1.0+r),r/(1.0+r),0)
		divCircle(x+r/2.0,y,r/2.0)
		newpath()
		moveto(x+r/2.0,y+r/2)
		circle([x,y+r/2.0],r/2.0)
		stroke(1-r/(1.0+r),r/(1.0+r),0)
		divCircle(x,y+r/2.0,r/2.0)
		newpath()
		moveto(x,y)
		circle([x-r/2.0,y],r/2.0)
		stroke(1-r/(1.0+r),r/(1.0+r),0)
		divCircle(x-r/2.0,y,r/2.0)
		newpath()
		moveto(x+r/2.0,y-r/2.0)
		circle(x,y-r/2.0,r/2.0)
		stroke(1-r/(1.0+r),r/(1.0+r),0)
		divCircle(x,y-r/2.0,r/2.0)
		

beginpage()
center()
scale(72/2.54)


# Circle
newpath()
#moveto(4,0)
circle(6)
stroke()
divCircle(0,0,6)


endpage()
flush()
