from piscript.PiModule import *
from math import *
import Vector as V

init("example07", 500, 500)

def divideSq(x,y,l):
	if l<0.8:
		return
	else:
		newpath()
		box(x+l/3,y,l/3,l)
		fill(1)
	
		newpath()
		box(x,y+l/3,l,l/3)
		fill(1)
		
		k=l/3
		divideSq(x,y,k)
		divideSq(x,y+2*k,k)
		divideSq(x+2*k,y+2*k,l/3)
		divideSq(x+2*k,y,l/3)

beginpage()
center()
scale(72/2.54)

newpath()
n=8.0
box(-n,-n,n*2,n*2)
fill(0,0,1)

divideSq(-n,-n,2*n)




endpage()
flush()
