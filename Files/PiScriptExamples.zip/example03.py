from piscript.PiModule import *

init("example03", 450, 450)

n=5

##Page 1:
beginpage()
center()
scale(72/2.54)
scalelinewidth(3)
newpath()
moveto(7,0)
for i in range(n):
	rotate(2*math.pi/n)
	lineto(7,0)
closepath()
fill(0.2,0.6,0.4)
stroke()
endpage()

##Page 2:
beginpage()
center()
scale(72/2.54)
scalelinewidth(3)
newpath()
moveto(7,0)
n=6
for i in range(n):
	lineto(7*math.cos(2*math.pi*i/n),7*math.sin(2*math.pi*i/n))
closepath()
fill(0.7,0,0.2)
stroke()
endpage()

finish()

