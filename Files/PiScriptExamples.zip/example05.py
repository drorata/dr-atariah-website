from piscript.PiModule import *
import piscript.Vector as V

init("example05", 500, 700)

r=1;

beginpage()
center()
scale(7)
#scalelinewidth(2)
P = [
[-30,-40],
[-10,40],
[30,-30]
]
Q=[0,10]

n=150
for i in range(0,n+1):
	k=float(i)/float(n)
	R=V.sum(V.scale(P[1],1-k),V.scale(Q,k))
	newpath()
	moveto(P[0])
	lineto(R)
	lineto(P[2])
	stroke(0,k,1-k)

	newpath()
	moveto(P[0])
	quadto(R,P[2])
	stroke(k,1-k,0)

	newpath()
	circle(R,float(r)/5)
	fill()

newpath()
circle(P[0],r)
fill()



newpath()
circle(P[2],r)
fill()

endpage()
finish()

