#if defined(_WIN32)
#pragma warning( disable : 4503)
//#pragma warning( disable : 4800)
//#pragma warning( disable : 4996)
//#pragma warning( disable : 4146)
//#pragma warning( disable : 4244)
//#pragma warning( disable : 4390)
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

#include <boost/tokenizer.hpp>
#include <boost/program_options.hpp>
#include <boost/optional.hpp>
#include <boost/iterator/reverse_iterator.hpp>
#include <boost/type_traits.hpp>

#define LAZY_KERNEL 1

#if LAZY_KERNEL
#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#else
#include <CGAL/Cartesian.h>
#include <CGAL/Gmpq.h>
#endif
#include <CGAL/Width_default_traits_3.h>
#include <CGAL/Width_3.h>
#include <CGAL/convex_hull_3.h>
#include <CGAL/Polyhedron_traits_with_normals_3.h>
#include <CGAL/Arr_spherical_gaussian_map_3/Arr_polyhedral_sgm.h>
#include <CGAL/Arr_spherical_gaussian_map_3/Arr_polyhedral_sgm_traits.h>
#include <CGAL/Arr_spherical_gaussian_map_3/Arr_polyhedral_sgm_polyhedron_3.h>

#include "Wrl_lexer.hpp"
#include "Build_surface.hpp"
#include "merge_coplanar_facets.hpp"
#include "compute_planes.hpp"
#include "is_valid.hpp"
#include "is_simple.hpp"

namespace po = boost::program_options;

#if LAZY_KERNEL
typedef CGAL::Exact_predicates_exact_constructions_kernel   Kernel;
#else
typedef CGAL::Gmpq                                          Number_type;
typedef CGAL::Cartesian<Number_type>                        Kernel;
#endif

typedef Kernel::Point_3                                     Point;
typedef Kernel::Plane_3                                     Plane;
typedef Kernel::Vector_3                                    Vector;

#if POLYHEDRON_TRAITS_WITH_NORMALS
typedef CGAL::Polyhedron_traits_with_normals_3<Kernel>      Polyhedron_traits;
#else
typedef Kernel                                              Polyhedron_traits;
#endif
typedef CGAL::Polyhedron_3<Polyhedron_traits>               Polyhedron;
typedef boost::is_same<Polyhedron::Plane_3, Plane>          Polyhedron_has_plane;

typedef Polyhedron::Vertex                                  Vertex;

typedef CGAL::Width_default_traits_3<Kernel>                Width_traits;
typedef CGAL::Width_3<Width_traits>                         Width;

typedef CGAL::Arr_polyhedral_sgm_traits<Kernel>             Gaussian_map_traits;
typedef CGAL::Arr_polyhedral_sgm<Gaussian_map_traits>       Gaussian_map;
// #define GAUSSIAN_MAP_POLYHEDRON_TRAITS_WITH_NORMALS 1
#if GAUSSIAN_MAP_POLYHEDRON_TRAITS_WITH_NORMALS
typedef CGAL::Polyhedron_traits_with_normals_3<Kernel>
  Gaussian_map_polyhedron_traits;
#else
typedef Kernel
  Gaussian_map_polyhedron_traits;
#endif
typedef CGAL::Arr_polyhedral_sgm_polyhedron_3<Gaussian_map, Gaussian_map_polyhedron_traits>
  Gaussian_map_polyhedron;
typedef boost::is_same<Gaussian_map_polyhedron::Plane_3, Plane>
  Gaussian_map_polyhedron_has_plane;
typedef CGAL::Arr_polyhedral_sgm_initializer<Gaussian_map,
                                             Gaussian_map_polyhedron>
  Gaussian_map_initializer;
typedef Gaussian_map_polyhedron::HalfedgeDS
  Gaussian_map_halfedge_ds;


#define VERSION "1_01"

/*! Extract the file name from the command line */
bool check_filename(const char * filename)
{
  struct stat buf;
  int rc = stat(filename, &buf);
  if (rc < 0 || ((buf.st_mode & S_IFDIR) == S_IFDIR)) {
    std::cerr << "Cannot find file " << filename << "!" << std::endl;
    return false;
  }
  return true;
}

// A helper function to simplify the main part.
template<class T>
std::ostream & operator<<(std::ostream & os, const std::vector<T> & v)
{
  copy(v.begin(), v.end(), std::ostream_iterator<T>(std::cout, " "));
  return os;
}

/* Compute minimum distance */
struct Compute_min_squared_distance {
  boost::optional<Kernel::FT> m_value;

  Compute_min_squared_distance() {}
  Compute_min_squared_distance(Kernel::FT max_value) : m_value(max_value) {}

  void operator()(Plane & plane)
  {
    // Take advantage of the fact that the sought distance is between the
    // origin and a plane (and not between a general point and the plane).
    // This simplifies the arithmetic.
    Vector v(CGAL::ORIGIN, plane.projection(CGAL::ORIGIN));
    Kernel::FT tmp = v.squared_length();    
    if (!m_value) m_value = tmp;
    else if (tmp < *m_value) m_value = tmp;
  }

  void operator()(Gaussian_map::Vertex & vertex)
  {
    // Vertices with boundary conditions may have degree 2. Skip them:
    if (vertex.degree() < 3) return;
    Gaussian_map::Halfedge_around_vertex_const_circulator
      hec3(vertex.incident_halfedges());
    Gaussian_map::Halfedge_around_vertex_const_circulator hec1 = hec3++;
    Gaussian_map::Halfedge_around_vertex_const_circulator hec2 = hec3++;

    CGAL_assertion(!CGAL::collinear((*hec1).face()->point(),
                                    (*hec2).face()->point(),
                                    (*hec3).face()->point()));
    Plane plane((*hec1).face()->point(), (*hec2).face()->point(),
                (*hec3).face()->point());
    operator()(plane);
  }
};

/*! Obtain the number of tokens in a string */
unsigned int get_num_tokens(const std::string & str)
{
  typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
  boost::char_separator<char> sep(", \t\n\r");
  tokenizer tokens(str, sep);
  unsigned int size = 0;
  for (tokenizer::iterator it = tokens.begin(); it != tokens.end(); ++it)
    ++size;
  return size;
}

/*! Parse the input file */
bool parse(const char * filename,
           std::vector<Point> & points,
           unsigned int & num_primitives,
           std::vector<unsigned int> & point_indices)
{
  // Open source file:
  std::ifstream src_stream(filename);

  try {
    Wrl_lexer lexer;
    src_stream >> lexer;
  } catch (std::exception & ex) {
    std::cerr << "Unexpected exception: " << ex.what()
              << "\nBye, bye!" << std::endl;
    return false;
  } catch (...) {
    std::cerr << "Unexpected exception. Bye, bye!" << std::endl;
    return false;
  }
  
  extern std::string * coord_str_ptr;
  extern std::string * coord_index_str_ptr;

#if 0
  std::cout << "coord: " << coord_str_ptr->c_str()
            << ", coordIndex: " << coord_index_str_ptr->c_str()
            << std::endl;
#endif

  unsigned int i;
  
  // Coords:
  unsigned int num_values = get_num_tokens(*coord_str_ptr);
  unsigned int size = num_values / 3;
  points.resize(size);
  std::istringstream svalue_points(*coord_str_ptr, std::istringstream::in);
  for (i = 0; i < size; i++) {
    Kernel::RT x, y, z;
    svalue_points >> x >> y >> z;
    points[i] = Point(x,y,z);
  }
  
  // Indices:
  num_values = get_num_tokens(*coord_index_str_ptr);
  num_primitives = 0;
  point_indices.resize(num_values);
  std::istringstream svalue_index(*coord_index_str_ptr, std::istringstream::in);
  for (i = 0; i < num_values; ++i) {
    int tmp = 0;
    svalue_index >> tmp;
    if (tmp == -1) num_primitives++;
    point_indices[i] = tmp;
  }

  return true;
}

struct Reflect {
  Point operator()(Point & p)
  {
    Vector v = CGAL::ORIGIN - p;
    return CGAL::ORIGIN + v;
  }
};

const char * s_method_opts[] = {"cw", "cch", "cgm"};

/*! Method id */
struct Method_id {
  Method_id(unsigned int id) : m_id(id) {}
  unsigned int m_id;
};

typedef std::vector<Method_id>         Vector_method_id;
typedef Vector_method_id::iterator     Vector_method_id_iter;

/*! Obtain number of method options */
unsigned int number_method_opts()
{ return sizeof(s_method_opts) / sizeof(char *); }

/*! Compare the i-th option to a given option */
static bool compare_method_opt(unsigned int i, const char * opt)
{ return strcmp(s_method_opts[i], opt) == 0; }

/* Overload the 'validate' function for the user-defined class */
void validate(boost::any & v, const std::vector<std::string> & values,
              Vector_method_id * target_type, int)
{
  for (unsigned int i = 0; i < number_method_opts(); ++i) {
    if (compare_method_opt(i, values[0].c_str())) {
      if (v.empty()) {
        Vector_method_id vec;
        vec.push_back(Method_id(i));
        v = boost::any(vec);
      } else {
        Vector_method_id vec = boost::any_cast<Vector_method_id>(v);
        vec.push_back(Method_id(i));
        v = boost::any(vec);
      }
      return;
    }
  }
#if BOOST_VERSION >= 104200
  throw po::validation_error(po::validation_error::invalid_option_value);
#else
  throw po::validation_error("invalid value");
#endif
}

/*! */
int main(int argc, char * argv[])
{  
  char * prog_name = strrchr(argv[0], '\\');
  prog_name = (prog_name) ? prog_name+1 : argv[0];
  bool convex_hull = true;
  
  std::vector<Point> points;                    // points
  unsigned int num_primitives;                  // number of primitives
  std::vector<unsigned int> point_indices;      // facets

  bool methods[] = {false, false, false};
  
  try {
    // Parse command line
    po::options_description opts("Viewer options");
    opts.add_options()
      ("help,H", "print help message")
      ("version,V", "print version string")
      ("convex-hull,c", po::value<bool>(&convex_hull), "use convex hull")
      ("method,m", po::value<Vector_method_id>()->composing(),
       "method options\n"
       "\tcw\n"
       "\tcch\n"
       "\tcgm\n"
       )
      ("input-file", po::value<std::string>(), "input file")
      ;

    po::positional_options_description p;
    p.add("input-file", -1);

    po::variables_map variable_map;
    po::store(po::command_line_parser(argc, argv).
              options(opts).positional(p).run(), variable_map);
    po::notify(variable_map);
    if (variable_map.count("help")) {
      std::cout << opts << std::endl;
      return 0;
    }

    if (variable_map.count("version")) {
      std::cout << VERSION << std::endl;
      return 0;
    }

    if (variable_map.count("method")) {
      Vector_method_id tmp = variable_map["method"].as<Vector_method_id>();
      for (Vector_method_id_iter it = tmp.begin(); it != tmp.end(); ++it)
        methods[(*it).m_id] = true;
    }
    
    const char * filename = variable_map["input-file"].as<std::string>().c_str();
    if (!check_filename(filename)) return -1;
    if (!parse(filename, points, num_primitives, point_indices)) return -1;
  }
  catch(std::exception & e) {
    std::cerr << "error: " << e.what() << std::endl;
    return 1;
  }
  catch(...) {
    std::cerr << "Exception of unknown type!" << std::endl;
  }

#if 0
  std::copy(points.begin(), points.end(),
            std::ostream_iterator<Point>(std::cout, "\n"));
#endif

  clock_t start_time, end_time;
  
  // Compute width using CGAL::width:
  if (methods[0]) {
    start_time = clock();
    Width simplex(points.begin(), points.end());
    Kernel::RT wnum, wdenom;
    simplex.get_squared_width(wnum, wdenom);
    end_time = clock();
    Kernel::FT width = wnum / wdenom;
    std::cout << "Squared Width: " << width << std::endl;
    std::cout << "Direction: " << simplex.get_build_direction() << std::endl;
    float width_time = (float) (end_time - start_time) / CLOCKS_PER_SEC;
    std::cout << "Width method: " << width_time << std::endl;
  }

  // Compute width using convex hull
  if (methods[1]){
    start_time = clock();
    std::vector<Point> points_sum(points.size() * points.size());
    std::vector<Point>::const_iterator it1, it2;
    std::vector<Point>::iterator it3 = points_sum.begin();
    for (it1 = points.begin(); it1 != points.end(); ++it1) {
      Vector v(CGAL::ORIGIN, *it1);
      for (it2 = points.begin(); it2 != points.end(); ++it2) *it3++ = (*it2) - v;
    }
    Polyhedron polyhedron;
    CGAL::convex_hull_3(points_sum.begin(), points_sum.end(), polyhedron);
    std::transform(polyhedron.facets_begin(), polyhedron.facets_end(),
                   polyhedron.planes_begin(), Plane_equation());

    Kernel kernel;
    merge_coplanar_facets(kernel, polyhedron, Polyhedron_has_plane());

    // Compute minimum squared distance:
    Compute_min_squared_distance compute_min_squared_distance;
    compute_min_squared_distance = for_each(polyhedron.planes_begin(),
                                            polyhedron.planes_end(),
                                            compute_min_squared_distance);
    end_time = clock();
    float ch_time = (float) (end_time - start_time) / CLOCKS_PER_SEC;
    std::cout << "Squared Width: " << *compute_min_squared_distance.m_value
              << std::endl;
    std::cout << "Convex hull method: " << ch_time << std::endl;
  }

  // Compute width using Gaussian map
  if (methods[2]) {
    start_time = clock();
    Gaussian_map_polyhedron polyhedron1, polyhedron2;
    Gaussian_map gaussian_map1, gaussian_map2;
    Kernel kernel;

    if (convex_hull) {
      CGAL::convex_hull_3(points.begin(), points.end(), polyhedron1);
    } else {
      Build_surface<Gaussian_map_halfedge_ds, Point> surface1(points,
                                                              num_primitives,
                                                              point_indices);
      polyhedron1.delegate(surface1);
      polyhedron1.normalize_border();
    }
    compute_planes(polyhedron1, Gaussian_map_polyhedron_has_plane());
    if (convex_hull) {
      merge_coplanar_facets(kernel, polyhedron1,
                            Gaussian_map_polyhedron_has_plane());
    }
    if (!is_valid(kernel, polyhedron1, Gaussian_map_polyhedron_has_plane())) {
      std::cerr << "Polyhedron 1 is invalid!" << std::endl;
      return -1;
    }
    if (!is_simple(kernel, polyhedron1)) {
      std::cerr << "Polyhedron 2 is not simple!" << std::endl;
      return -1;
    }

    Gaussian_map_initializer gm_initializer1(gaussian_map1);
    gm_initializer1(polyhedron1);

    // Reflect the points and the facets:
    std::vector<Point> points_ref(points.size());
    std::transform(points.begin(), points.end(), points_ref.begin(), Reflect());

    if (convex_hull) {
      CGAL::convex_hull_3(points_ref.begin(), points_ref.end(), polyhedron2);
    } else {
      std::vector<unsigned int> point_indices_ref(point_indices.size());
      std::vector<unsigned int>::iterator end_it = point_indices.end();
      --end_it;
      copy(boost::make_reverse_iterator(end_it),
           boost::make_reverse_iterator(point_indices.begin()),
           point_indices_ref.begin()); 
      end_it = point_indices_ref.end();
      --end_it;
      *end_it = -1;
      Build_surface<Gaussian_map_halfedge_ds, Point> surface2(points_ref,
                                                              num_primitives,
                                                              point_indices_ref);
      polyhedron2.delegate(surface2);
      polyhedron2.normalize_border();
    }
    compute_planes(polyhedron2, Gaussian_map_polyhedron_has_plane());
    if (convex_hull) {
      merge_coplanar_facets(kernel, polyhedron2,
                            Gaussian_map_polyhedron_has_plane());
    }
    if (!is_valid(kernel, polyhedron2, Gaussian_map_polyhedron_has_plane())) {
      std::cerr << "Polyhedron 2 is invalid!" << std::endl;
      return -1;
    }
    if (!is_simple(kernel, polyhedron2)) {
      std::cerr << "Polyhedron 2 is not simple!" << std::endl;
      return -1;
    }
    Gaussian_map_initializer gm_initializer2(gaussian_map2);
    gm_initializer2(polyhedron2);
    
    Gaussian_map gaussian_map;
    gaussian_map.minkowski_sum(gaussian_map1, gaussian_map2);
    // Compute minimum squared distance:
    Compute_min_squared_distance compute_min_squared_distance;
    compute_min_squared_distance = for_each(gaussian_map.vertices_begin(),
                                            gaussian_map.vertices_end(),
                                            compute_min_squared_distance);
    end_time = clock();
    float gm_time = (float) (end_time - start_time) / CLOCKS_PER_SEC;
    std::cout << "Squared Width: " << *compute_min_squared_distance.m_value
              << std::endl;
    std::cout << "Gaussian map method: " << gm_time << std::endl;
  }
  
  return 0;
}
