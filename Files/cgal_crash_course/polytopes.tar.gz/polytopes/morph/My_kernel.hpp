#ifndef MYKERNEL_HPP
#define MYKERNEL_HPP

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Origin.h>

// T_Kernel is the new kernel, and Kernel_base is the old kernel
template < typename T_Kernel, typename Kernel_Base >
class My_cartesian_base : public Kernel_Base::template Base<T_Kernel>::Type
{
public:
  typedef T_Kernel                                              Kernel;
  typedef typename Kernel_Base::template Base<T_Kernel>::Type   Old_kernel;
  typedef typename Old_kernel::Point_3                          Old_point_3;
  typedef typename Old_kernel::RT                               RT;

  /*! The new point type */
  class New_point_3 : public Old_point_3 {
  private:
    /*! Fields extending the point */
    New_point_3 * m_source_point1;
    New_point_3 * m_source_point2;

  public:
    New_point_3(New_point_3 * source_point1 = NULL, 
                New_point_3 * source_point2 = NULL) : 
      m_source_point1(source_point1), 
      m_source_point2(source_point2) {}

    New_point_3(const CGAL::Origin origin, 
                New_point_3 * source_point1 = NULL, 
                New_point_3 * source_point2 = NULL) :
      Old_point_3(origin), 
      m_source_point1(source_point1), 
      m_source_point2(source_point2) {}

    New_point_3(const RT & x, const RT & y, const RT & z, 
                New_point_3 * source_point1 = NULL, 
                New_point_3 * source_point2 = NULL) :
      Old_point_3(x, y, z), 
      m_source_point1(source_point1), 
      m_source_point2(source_point2) {}

    New_point_3(const RT & x,  const RT & y, const RT & z, const RT & w, 
                New_point_3 * source_point1 = NULL, 
                New_point_3 * source_point2 = NULL) :
      Old_point_3(x, y, z, w), 
      m_source_point1(source_point1), 
      m_source_point2(source_point2) {}
	
    New_point_3 * get_source_point1() const { return m_source_point1; }
    New_point_3 * get_source_point2() const { return m_source_point2; }

    bool operator==(const New_point_3 &p) const
    {
      return false;
    }

    bool operator!=(const New_point_3 & p) const
    {
      return !(*this == p);
    }

  };

  template <typename K, typename Old_kernel>
  class My_construct_point_3 {
    typedef typename K::RT         RT;
    typedef typename K::Point_3    Point_3;
    typedef typename Point_3::Rep  Rep;
  public:
    typedef Point_3                result_type;

    // Note : the CGAL::Return_base_tag is really internal CGAL stuff.
    // Unfortunately it is needed for optimizing away copy-constructions,
    // due to current lack of delegating constructors in the C++ standard.
    Rep operator()(CGAL::Return_base_tag,
                   New_point_3 * source_point1 = NULL, 
                   New_point_3 * source_point2 = NULL) const
    { return Rep(source_point1, source_point2); }

    Rep operator()(CGAL::Return_base_tag, CGAL::Origin origin,
                   New_point_3 * source_point1 = NULL, 
                   New_point_3 * source_point2 = NULL) const
    { return Rep(origin, source_point1, source_point2); }

    Rep operator()(CGAL::Return_base_tag,
                   const RT & x, const RT & y, const RT & z,
                   New_point_3 * source_point1 = NULL, 
                   New_point_3 * source_point2 = NULL) const
    { return Rep(x, y, z, source_point1, source_point2); }

    Rep operator()(CGAL::Return_base_tag,
                   const RT & x, const RT & y,
                   const RT & z, const RT & w,
                   New_point_3 * source_point1 = NULL, 
                   New_point_3 * source_point2 = NULL) const
    { return Rep(x, y, z, w, source_point1, source_point2); }

    Point_3 operator()(New_point_3 * source_point1 = NULL, 
                       New_point_3 * source_point2 = NULL) const
    { return New_point_3(0, 0, 0, source_point1, source_point2); }

    Point_3 operator()(CGAL::Origin origin,
                       New_point_3 * source_point1 = NULL, 
                       New_point_3 * source_point2 = NULL) const
    { return New_point_3(0, 0, 0, source_point1, source_point2); }

    Point_3 operator()(const RT & x, const RT & y, const RT & z,
                       New_point_3 * source_point1 = NULL, 
                       New_point_3 * source_point2 = NULL) const
    { return New_point_3(x, y, z, source_point1, source_point2); }

    Point_3 operator()(const RT & x, const RT & y, const RT & z, const RT & w,
                       New_point_3 * source_point1 = NULL, 
                       New_point_3 * source_point2 = NULL)
      const
    { return New_point_3(x, y, z, w, source_point1, source_point2); }
  };

public:
  typedef New_point_3                                   Point_3;
  typedef My_construct_point_3<Kernel, Old_kernel>      Construct_point_3;

  Construct_point_3 construct_point_3_object() const
  { return Construct_point_3(); }

  template < typename Kernel2 >
  struct Base { typedef My_cartesian_base<Kernel2, Kernel_Base>  Type; };
};


/*! The extended Kernel type */
template <typename FT_>
struct Ext_kernel : public CGAL::
  Type_equality_wrapper<My_cartesian_base<Ext_kernel<FT_>,
                                          CGAL::Simple_cartesian<FT_> >,
                        Ext_kernel<FT_> >
{};

// template <typename FT_>
// struct Ext_kernel
//   : public My_cartesian_base<Ext_kernel<FT_>, CGAL::Cartesian<FT_> >
// {};

#endif
