#ifndef POLYHEDRON_VIEWER_H
#define POLYHEDRON_VIEWER_H

#include <string>
#include <sstream>

#include <boost/type_traits.hpp>

#include <CGAL/basic.h>
#include <CGAL/tags.h>
#include <CGAL/Origin.h>
#define USE_LAZY_KERNEL 0
#if USE_LAZY_KERNEL
#include <CGAL/Lazy_kernel.h>
#else
#include <CGAL/Filtered_kernel.h>
#endif
#include <CGAL/Gmpq.h>
#include <CGAL/Polyhedron_traits_with_normals_3.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/HalfedgeDS_vector.h>
#include <CGAL/IO/Polyhedron_iostream.h>
#include <CGAL/enum.h>

#include "My_kernel.hpp"
#include "compute_planes.hpp"

class Polyhedron_viewer {
public:
  typedef CGAL::Gmpq                                        Number_type;
  typedef Ext_kernel<Number_type>                           My_raw_kernel;
#if USE_LAZY_KERNEL
  typedef My_raw_kernel                                     Exact_kernel;
  typedef CGAL::Simple_cartesian<CGAL::Interval_nt_advanced> Approximate_kernel;
  typedef CGAL::Cartesian_converter<Exact_kernel, Approximate_kernel>
                                                            E2A;
  typedef CGAL::Lazy_kernel_adaptor<My_raw_kernel, Approximate_kernel, E2A>
                                                            My_kernel;
#else
  typedef CGAL::Filtered_kernel_adaptor<My_raw_kernel>      My_kernel;
#endif  
  typedef My_kernel::Point_3                                Point_3;
  typedef My_kernel::Plane_3                                Plane_3;
  typedef My_kernel::Vector_3                               Vector_3;

  typedef CGAL::Polyhedron_traits_with_normals_3<My_kernel> Polyhedron_traits;
  typedef CGAL::Polyhedron_3<Polyhedron_traits>             Polyhedron;
  typedef Polyhedron::Vertex                                Vertex;
  typedef Polyhedron::Facet                                 Facet;
  typedef Polyhedron::Facet_iterator                        Facet_iterator;
  typedef Polyhedron::Vertex_iterator                       Vertex_iterator;
  typedef Polyhedron::Point_iterator                        Point_iterator;
  typedef Polyhedron::Edge_iterator                         Edge_iterator;
  typedef Polyhedron::HalfedgeDS                            HalfedgeDS;
  
public:
  /*! Constructor */
  Polyhedron_viewer();

  /*! Destructor */
  ~Polyhedron_viewer();

  /*! Parse the input file */
  bool parse(const char * filename);

  /*! Draw the data structure */
  void draw(bool drawLines = true);

  /*! Clear the internal representation */
  void clear();

  /*! Return true if the internal representation is empty */
  bool is_empty() const { return m_polyhedron.empty(); }

  /*! Print statistics */
  void print_stat();

  /*! Update the representation */
  void update();

  /*! Set the polyhedron */
  void set_polyhedron(Polyhedron & polyhedron);

  /*! Obtain the polyhedron */
  Polyhedron & get_polyhedron();

  /*! Clean the normals */
  void clean_normals() { m_dirty_normals = true; }
  
private:
  /*! Indicates whether the polyhedron has been built */
  bool m_dirty;

  /*! Indicates whether the polyhedron normals have been built */
  bool m_dirty_normals;
  
  /*! The resulting polyhedron */
  Polyhedron m_polyhedron;

  /*! The coordinates */
  std::vector<Point_3> m_coords;

  /*! The number of primitives */
  unsigned int m_num_primitives;

  /*! The facets */
  std::vector<unsigned int> m_coord_indices;
  
  /*! The time is took to compute the minkowski sum in seconds */
  float m_time;

  /*! Draw a facet */
  void draw_facet(Facet_iterator i);

  /*! Draw the boundary of a facet */
  void draw_facet_boundary(Facet_iterator i);

  /*! Update the normals */
  void update_normals()
  {
    compute_planes(m_polyhedron,
                   boost::is_same<Polyhedron::Plane_3, Plane_3>());
    m_dirty_normals = false;
  }

  /*! Obtain the number of tokens in a string */
  unsigned int get_num_tokens(const std::string & str);
};

#endif
