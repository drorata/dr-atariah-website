#ifndef SPHERE_BOUND_H
#define SPHERE_BOUND_H

#include <CGAL/Cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>

#include <vector>
#include <list>

class Sphere_bound {
private:
  // Inexact types:
  typedef float                                         Inexact_NT;
  typedef CGAL::Cartesian<Inexact_NT>                   Inexact_kernel;

  typedef CGAL::Min_sphere_of_spheres_d_traits_3<Inexact_kernel,Inexact_NT>
    Min_sphere_traits;
  typedef CGAL::Min_sphere_of_spheres_d<Min_sphere_traits>
    Min_sphere;
  typedef Min_sphere_traits::Sphere                     Inexact_sphere_3;
  typedef Inexact_kernel::Point_3                       Inexact_point_3;
  typedef Inexact_kernel::Vector_3                      Inexact_vector_3;

  /*! Convert the (exact) point of a polyhedron vertex to a sphere */
  template <typename Polyhedron>
  class Vertex_2_sphere {
  private:
    typedef typename Polyhedron::Vertex                   Vertex;
    typedef typename Polyhedron::Traits                   Traits;
    typedef typename Traits::Point_3                      Point_3;

  public:
    Inexact_sphere_3 operator()(const Vertex & vertex) const
    {
      const Point_3 & point = vertex.point();
      float x = CGAL::to_double(point.x());
      float y = CGAL::to_double(point.y());
      float z = CGAL::to_double(point.z());
      Inexact_point_3 inexact_point(x,y,z);
      return Inexact_sphere_3(inexact_point, 0);
    }
  };

public:
  /*! Calculate the sphere bound of a Polyhedron */
  template <typename Polyhedron>
  void operator()(const Polyhedron & polyhedron, float * center, float & radius)
  {
    std::vector<Inexact_sphere_3> spheres;
    if (polyhedron.empty()) return;
    spheres.resize(polyhedron.size_of_vertices());
    std::transform(polyhedron.vertices_begin(), polyhedron.vertices_end(),
                   spheres.begin(), Vertex_2_sphere<Polyhedron>());
    Min_sphere min_sphere(spheres.begin(), spheres.end());
    std::copy(min_sphere.center_cartesian_begin(),
              min_sphere.center_cartesian_end(),
              center);
    radius = min_sphere.radius();
  }

private:
  /*! Compute the (inexact) sphere bound of a polyhedron viewer */
  class Polyhedron_viewer_2_sphere {
  public:
    template <class Polyhedron_viewer>
    Inexact_sphere_3 operator()(Polyhedron_viewer * pv) const
    {
      float center[3];
      float radius = 0;
      Sphere_bound()(pv->get_polyhedron(), center, radius);
      Inexact_point_3 center_point(center[0], center[1], center[2]);
      return Inexact_sphere_3(center_point, radius * radius);
    }
  };
  
public:  
  /*! Calculate the sphere bound of a range of Polyhedron viewers */
  template <typename Polyhedron_viewer_iterator>
  void operator()(Polyhedron_viewer_iterator begin,
                  Polyhedron_viewer_iterator end,
                  float * center, float & radius)
  {
    // Count the veiwers:
    unsigned int size = 0;
    Polyhedron_viewer_iterator pvi;
    for (pvi = begin; pvi != end; ++pvi) size++;

    std::vector<Inexact_sphere_3> spheres;
    spheres.resize(size);
    std::transform(begin, end, spheres.begin(), Polyhedron_viewer_2_sphere());
    Min_sphere min_sphere(spheres.begin(), spheres.end());
    std::copy(min_sphere.center_cartesian_begin(),
              min_sphere.center_cartesian_end(),
              center);
    radius = min_sphere.radius();
  }
};

#endif
