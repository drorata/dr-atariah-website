#ifndef IS_VALID_HPP
#define IS_VALID_HPP

#include <boost/type_traits.hpp>

/*! Check the validity of a polyhedron
 * If the facets of the input polyhedron are not all triangles, and the
 * coordinates of the ticespoints are provided in floating point, it
 * is most likely that the vertices of each facet are not colinear.
 *
 * If the vertices of a facet are not colinear the input data is
 * erroneous, and the resulting polyhedron is invalid.
 *
 * The Gaussian-map method, for example, is sensitive to this erroneous data.
 */
template <typename Kernel, typename Polyhedron>
bool is_valid(Kernel & kernel, Polyhedron & polyhedron, boost::false_type)
{
  typedef typename Polyhedron::Facet_const_iterator     Facet_iterator;
  typedef typename Polyhedron::Halfedge_around_facet_const_circulator
    Halfedge_around_facet_const_circulator;

  typedef typename Kernel::Plane_3                      Vector_3;
  typedef typename Kernel::Has_on_3                     Has_on_3;
  
  Has_on_3 has_on = kernel.has_on_3_object();
  Facet_iterator fit;
  for (fit = polyhedron.facets_begin(); fit != polyhedron.facets_end(); ++fit) {
    Halfedge_around_facet_const_circulator he_start = fit->facet_begin();
    Halfedge_around_facet_const_circulator he = he_start;
    typename Kernel::Plane_3 plane(he->vertex()->point(), fit->plane());
    for (++he; he != he_start; ++he) {
      if (!has_on(plane, he->vertex()->point())) return false;
    }
  }

  return true;
}

template <typename Kernel, typename Polyhedron>
bool is_valid(Kernel & kernel, Polyhedron & polyhedron, boost::true_type)
{
  typedef typename Polyhedron::Facet_const_iterator     Facet_iterator;
  typedef typename Polyhedron::Halfedge_around_facet_const_circulator
    Halfedge_around_facet_const_circulator;

  typedef typename Kernel::Plane_3                      Plane_3;
  typedef typename Kernel::Has_on_3                     Has_on_3;
  
  Has_on_3 has_on = kernel.has_on_3_object();
  Facet_iterator fit;
  for (fit = polyhedron.facets_begin(); fit != polyhedron.facets_end(); ++fit) {
    const Plane_3 & plane = fit->plane();
    Halfedge_around_facet_const_circulator he_start = fit->facet_begin();
    Halfedge_around_facet_const_circulator he = he_start;
    if (!has_on(plane, he->vertex()->point())) return false;
    for (++he; he != he_start; ++he) {
      if (!has_on(plane, he->vertex()->point())) return false;
    }
  }

  return true;
}

#endif
