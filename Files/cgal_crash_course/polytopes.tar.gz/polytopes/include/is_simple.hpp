#ifndef IS_SIMPLE_HPP
#define IS_SIMPLE_HPP

template <typename Kernel, typename Polyhedron>
bool is_simple(Kernel & kernel, Polyhedron & polyhedron)
{
  typedef typename Polyhedron::Edge_const_iterator      Edge_iterator;
  typedef typename Kernel::Equal_3                      Equal_3;
  Equal_3 equal = kernel.equal_3_object();
  Edge_iterator eit;
  for (eit = polyhedron.edges_begin(); eit != polyhedron.edges_end(); ++eit) {
    if (equal(eit->face()->plane(), eit->opposite()->face()->plane()))
      return false;
  }
  
  return true;
}

#endif
