#ifndef COMPUTE_PLANES_HPP
#define COMPUTE_PLANES_HPP

#include <algorithm>
#include <boost/type_traits.hpp>

/*! Compute the equation of the normal to a facet */
struct Normal_equation {
  template <typename Facet>
  typename Facet::Plane_3 operator()(Facet & f) {
    typename Facet::Halfedge_handle h = f.halfedge();
    return CGAL::cross_product(h->next()->vertex()->point() -
                               h->vertex()->point(),
                               h->next()->next()->vertex()->point() -
                               h->next()->vertex()->point());
  }
};

template <typename Polyhedron>
void compute_planes(Polyhedron & polyhedron, boost::false_type)
{
  std::transform(polyhedron.facets_begin(), polyhedron.facets_end(),
                 polyhedron.planes_begin(), Normal_equation());
}

/*! Compute the equation of the undelying plane of a facet */
struct Plane_equation {
  template <typename Facet>
  typename Facet::Plane_3 operator()(Facet & f) {
    typename Facet::Halfedge_handle h = f.halfedge();
    return typename Facet::Plane_3(h->vertex()->point(),
                                   h->next()->vertex()->point(),
                                   h->next()->next()->vertex()->point());
  }
};

template <typename Polyhedron>
void compute_planes(Polyhedron & polyhedron, boost::true_type)
{
  std::transform(polyhedron.facets_begin(), polyhedron.facets_end(),
                 polyhedron.planes_begin(), Plane_equation());
}

#endif
