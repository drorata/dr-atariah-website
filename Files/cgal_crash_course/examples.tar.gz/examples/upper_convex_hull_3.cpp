#include <iostream>
#include <algorithm>
#include <vector>

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel  Kernel;

template <typename Iterator, typename Output, typename Traits>
Output upper_hull3(Iterator first, Iterator beyond, Output result, Traits traits)
{ 
  typename Traits::Less_xy_2 less_xy = traits.less_xy_2_object();
  typename Traits::Left_turn_2 left_turn = traits.left_turn_2_object();
    
  if (first == beyond) return result;   // empty sequence
  std::sort(first, beyond, less_xy);    // lexicographic sorting
  std::vector<Iterator> hull;
  hull.push_back(first);                // sentinel
  Iterator p = first;                   // last point on the hull
  // scan all points from left to right for upper convex hull
  for (++first; first != beyond; ++first) {
    while (left_turn(*(hull.back()), *p, *first)) {
      p = hull.back();
      hull.pop_back();
    }
    hull.push_back(p);
    p = first;
  }
  hull.push_back(p);
  typename std::vector<Iterator>::iterator i = hull.begin();
  ++i;                                  // skip sentinel
  while (i != hull.end()) *result++ = **i++;
  return result;
}

int main()
{
  Kernel kernel;
  CGAL::set_ascii_mode(std::cin);
  CGAL::set_ascii_mode(std::cout);
  std::istream_iterator<Kernel::Point_2> in_start( std::cin );
  std::istream_iterator<Kernel::Point_2> in_end;
  std::vector<Kernel::Point_2> points;
  std::copy(in_start, in_end, std::back_inserter(points));
  std::ostream_iterator<Kernel::Point_2> out(std::cout, "\n");
  upper_hull3(points.begin(), points.end(), out, kernel);
  return 0;
}
