#include <vector>
#include <iostream>

#include <CGAL/Cartesian.h>
// #include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/convex_hull_2.h>
#include <CGAL/ch_jarvis.h>
#include <CGAL/ch_melkman.h>

#include "read_objects.h"

// typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef CGAL::Cartesian<double>                             Kernel;
typedef Kernel::Point_2                                     Point_2;

int main(int argc , char* argv[]) {
  std::cout << std::setiosflags(std::ios::fixed);
  std::cout << std::setprecision(20);
  std::vector<Point_2> in, out;
  const char* filename = (argc > 1) ? argv [ 1 ] : "ch points.dat";
  read_objects<Point_2>(filename, std::back_inserter(in));
  // CGAL::ch_akl_toussaint(in.begin(), in.end(), std::back_inserter(out));
  // CGAL::ch_bykat(in.begin(), in.end(), std::back_inserter(out));
  // CGAL::ch_eddy(in.begin(), in.end(), std::back_inserter(out));
  CGAL::ch_graham_andrew(in.begin(), in.end(), std::back_inserter(out));
  // CGAL::ch_jarvis(in.begin(), in.end(), std::back_inserter(out));
  // CGAL::ch_melkman(in.begin(), in.end(), std::back_inserter(out));
  std::copy(out.begin(), out.end(),
            std::ostream_iterator<Point_2>(std::cout, "\n"));
  return 0;
}  
