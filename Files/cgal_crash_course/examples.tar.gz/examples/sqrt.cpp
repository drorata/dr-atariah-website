#include <CGAL/Cartesian.h>

typedef double                  NT;
typedef CGAL::Cartesian<NT>     Kernel;
int main()
{
  NT sqrt2 = sqrt(NT(2));
  Kernel::Point_2 p(0,0), q(sqrt2, sqrt2);
  Kernel::Circle_2 C(p,4);
  assert(C.has_on_boundary(q));
  return 0;
}
