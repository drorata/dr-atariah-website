#include <iostream>
#include <algorithm>
#include <vector>

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel  Kernel;

template <typename Iterator, typename Pred>   // bidirectional iterator
Iterator remove_if_triple(Iterator first, Iterator beyond, Pred pred)
{ 
  if (first == beyond) return first;
  // setup iterators i,j,k for scanning triples
  Iterator i = first, j = first;
  if (++j == beyond) return j;  // i,j mark two elements on top of stack
  Iterator k = j;               // k marks the third value in the sequence
  while (++k != beyond) {
    while ((pred(*i, *j, *k))) { 
      j = i;                    // remove one element from stack
      if (i == first) break;    // explicit test for stack underflow
      --i;                      // remove one element from the stack, part 2
    }
    i = j;                      // push new element from k on stack
    ++j;
    *j = *k;
  }
  return ++j;
}

template <typename Iterator, typename Output, typename Traits>
Output upper_hull4(Iterator first, Iterator beyond, Output result, Traits traits)
{ 
  typename Traits::Less_xy_2 less_xy = traits.less_xy_2_object();
  typename Traits::Left_turn_2 left_turn = traits.left_turn_2_object();
    
  if (first == beyond) return result;  // empty sequence
  std::sort(first, beyond, less_xy);   // lexicographic sorting
  Iterator hull_end = remove_if_triple(first, beyond, left_turn);
  return std::copy(first, hull_end, result);
}

int main()
{
  Kernel kernel;
  CGAL::set_ascii_mode(std::cin);
  CGAL::set_ascii_mode(std::cout);
  std::istream_iterator<Kernel::Point_2> in_start( std::cin );
  std::istream_iterator<Kernel::Point_2> in_end;
  std::vector<Kernel::Point_2> points;
  std::copy(in_start, in_end, std::back_inserter(points));
  std::ostream_iterator<Kernel::Point_2> out(std::cout, "\n");
  upper_hull4(points.begin(), points.end(), out, kernel);
  return 0;
}
