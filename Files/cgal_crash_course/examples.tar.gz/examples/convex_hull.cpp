#include <iostream>

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/convex_hull_2.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef Kernel::Point_2 Point_2;

int main() {
  CGAL::set_ascii_mode (std::cin);
  CGAL::set_ascii_mode (std::cout);
  std::istream_iterator<Point_2> in_start( std::cin );
  std::istream_iterator<Point_2> in_end;
  std::ostream_iterator<Point_2> out(std::cout, "\n");
  CGAL::convex_hull_2(in_start, in_end, out);
  return 0;
}  
