#include <vector>
#include <iostream>

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/convex_hull_2.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef Kernel::Point_2                                     Point_2;

int main() {
  std::vector<Point_2> in, out;
  in.push_back(Point_2(0,-1)); in.push_back(Point_2(1,0));
  in.push_back(Point_2(0,1));  in.push_back(Point_2(-1,0));
  in.push_back(Point_2(0,0));
  CGAL::convex_hull_2(in.begin(), in.end(), std::back_inserter(out));
  std::copy(out.begin(), out.end(),
            std::ostream_iterator<Point_2>(std::cout, "\n"));
  return 0;
}  
